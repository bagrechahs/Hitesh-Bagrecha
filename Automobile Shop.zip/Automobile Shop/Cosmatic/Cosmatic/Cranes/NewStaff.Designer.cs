﻿namespace Bootique
{
    partial class NewStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewStaff));
            this.DOF = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.txtAdhar = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtFormNo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboClass = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPlaceOfB = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.txtFoccupation = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtGardianAdd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.txtGardian = new System.Windows.Forms.TextBox();
            this.txtCast = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtReligion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMNm = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFNm = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSNm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DOF
            // 
            this.DOF.Location = new System.Drawing.Point(126, 397);
            this.DOF.Margin = new System.Windows.Forms.Padding(2);
            this.DOF.Name = "DOF";
            this.DOF.Size = new System.Drawing.Size(175, 20);
            this.DOF.TabIndex = 104;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(11, 402);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(95, 13);
            this.label20.TabIndex = 103;
            this.label20.Text = "Date Of Joining";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // txtAdhar
            // 
            this.txtAdhar.BackColor = System.Drawing.Color.Snow;
            this.txtAdhar.Location = new System.Drawing.Point(126, 347);
            this.txtAdhar.Margin = new System.Windows.Forms.Padding(2);
            this.txtAdhar.Name = "txtAdhar";
            this.txtAdhar.Size = new System.Drawing.Size(248, 20);
            this.txtAdhar.TabIndex = 102;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 347);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 13);
            this.label18.TabIndex = 101;
            this.label18.Text = "Adhar No.";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // txtContact
            // 
            this.txtContact.BackColor = System.Drawing.Color.Snow;
            this.txtContact.Location = new System.Drawing.Point(10, 136);
            this.txtContact.Margin = new System.Windows.Forms.Padding(2);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(118, 20);
            this.txtContact.TabIndex = 118;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(7, 117);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 13);
            this.label17.TabIndex = 117;
            this.label17.Text = "Contact No.";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(419, 72);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 13);
            this.label16.TabIndex = 109;
            this.label16.Text = " Staff Image";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Image = ((System.Drawing.Image)(resources.GetObject("btnRegister.Image")));
            this.btnRegister.Location = new System.Drawing.Point(407, 403);
            this.btnRegister.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(163, 41);
            this.btnRegister.TabIndex = 119;
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(482, 203);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(54, 19);
            this.btnClear.TabIndex = 112;
            this.btnClear.Text = "clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(407, 203);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(2);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(59, 19);
            this.btnLoad.TabIndex = 111;
            this.btnLoad.Text = "load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(407, 96);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 93);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 110;
            this.pictureBox1.TabStop = false;
            // 
            // txtFormNo
            // 
            this.txtFormNo.Enabled = false;
            this.txtFormNo.Location = new System.Drawing.Point(15, 59);
            this.txtFormNo.Margin = new System.Windows.Forms.Padding(2);
            this.txtFormNo.Name = "txtFormNo";
            this.txtFormNo.Size = new System.Drawing.Size(88, 20);
            this.txtFormNo.TabIndex = 108;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 44);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 107;
            this.label15.Text = "Form No.";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // comboClass
            // 
            this.comboClass.BackColor = System.Drawing.Color.Snow;
            this.comboClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboClass.FormattingEnabled = true;
            this.comboClass.Items.AddRange(new object[] {
            "Helping Boy",
            "Manager",
            "Computer Operator",
            "Guard",
            "Cashier"});
            this.comboClass.Location = new System.Drawing.Point(126, 423);
            this.comboClass.Margin = new System.Windows.Forms.Padding(2);
            this.comboClass.Name = "comboClass";
            this.comboClass.Size = new System.Drawing.Size(175, 21);
            this.comboClass.TabIndex = 106;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(12, 430);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 13);
            this.label13.TabIndex = 105;
            this.label13.Text = "Post";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // txtPlaceOfB
            // 
            this.txtPlaceOfB.BackColor = System.Drawing.Color.Snow;
            this.txtPlaceOfB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlaceOfB.Location = new System.Drawing.Point(126, 323);
            this.txtPlaceOfB.Margin = new System.Windows.Forms.Padding(2);
            this.txtPlaceOfB.Name = "txtPlaceOfB";
            this.txtPlaceOfB.Size = new System.Drawing.Size(248, 19);
            this.txtPlaceOfB.TabIndex = 100;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(12, 323);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 99;
            this.label12.Text = "Place of Birth";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(126, 289);
            this.DOB.Margin = new System.Windows.Forms.Padding(2);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(175, 20);
            this.DOB.TabIndex = 98;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 293);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 13);
            this.label11.TabIndex = 97;
            this.label11.Text = "Date Of Birth";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // txtFoccupation
            // 
            this.txtFoccupation.BackColor = System.Drawing.Color.Snow;
            this.txtFoccupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFoccupation.Location = new System.Drawing.Point(126, 254);
            this.txtFoccupation.Margin = new System.Windows.Forms.Padding(2);
            this.txtFoccupation.Name = "txtFoccupation";
            this.txtFoccupation.Size = new System.Drawing.Size(248, 19);
            this.txtFoccupation.TabIndex = 96;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 254);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 13);
            this.label10.TabIndex = 95;
            this.label10.Text = "Father\'s occupation";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // txtGardianAdd
            // 
            this.txtGardianAdd.BackColor = System.Drawing.Color.Snow;
            this.txtGardianAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGardianAdd.Location = new System.Drawing.Point(10, 76);
            this.txtGardianAdd.Margin = new System.Windows.Forms.Padding(2);
            this.txtGardianAdd.Multiline = true;
            this.txtGardianAdd.Name = "txtGardianAdd";
            this.txtGardianAdd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtGardianAdd.Size = new System.Drawing.Size(163, 33);
            this.txtGardianAdd.TabIndex = 116;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 61);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 13);
            this.label9.TabIndex = 115;
            this.label9.Text = "Refference Address";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtGardian
            // 
            this.txtGardian.BackColor = System.Drawing.Color.Snow;
            this.txtGardian.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGardian.Location = new System.Drawing.Point(10, 36);
            this.txtGardian.Margin = new System.Windows.Forms.Padding(2);
            this.txtGardian.Name = "txtGardian";
            this.txtGardian.Size = new System.Drawing.Size(163, 19);
            this.txtGardian.TabIndex = 114;
            // 
            // txtCast
            // 
            this.txtCast.BackColor = System.Drawing.Color.Snow;
            this.txtCast.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCast.Location = new System.Drawing.Point(273, 222);
            this.txtCast.Margin = new System.Windows.Forms.Padding(2);
            this.txtCast.Name = "txtCast";
            this.txtCast.Size = new System.Drawing.Size(88, 19);
            this.txtCast.TabIndex = 94;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(237, 225);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 93;
            this.label7.Text = "Cast";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtReligion
            // 
            this.txtReligion.BackColor = System.Drawing.Color.Snow;
            this.txtReligion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReligion.Location = new System.Drawing.Point(126, 222);
            this.txtReligion.Margin = new System.Windows.Forms.Padding(2);
            this.txtReligion.Name = "txtReligion";
            this.txtReligion.Size = new System.Drawing.Size(88, 19);
            this.txtReligion.TabIndex = 92;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 222);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 91;
            this.label6.Text = "Religion";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 21);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 113;
            this.label8.Text = "Refference Name";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtAdd
            // 
            this.txtAdd.BackColor = System.Drawing.Color.Snow;
            this.txtAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdd.Location = new System.Drawing.Point(126, 176);
            this.txtAdd.Margin = new System.Windows.Forms.Padding(2);
            this.txtAdd.Multiline = true;
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAdd.Size = new System.Drawing.Size(248, 33);
            this.txtAdd.TabIndex = 90;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 176);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 89;
            this.label5.Text = "Address";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtMNm
            // 
            this.txtMNm.BackColor = System.Drawing.Color.Snow;
            this.txtMNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMNm.Location = new System.Drawing.Point(126, 144);
            this.txtMNm.Margin = new System.Windows.Forms.Padding(2);
            this.txtMNm.Name = "txtMNm";
            this.txtMNm.Size = new System.Drawing.Size(248, 19);
            this.txtMNm.TabIndex = 88;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 144);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 87;
            this.label4.Text = "Mother\'s Name";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtFNm
            // 
            this.txtFNm.BackColor = System.Drawing.Color.Snow;
            this.txtFNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFNm.Location = new System.Drawing.Point(126, 115);
            this.txtFNm.Margin = new System.Windows.Forms.Padding(2);
            this.txtFNm.Name = "txtFNm";
            this.txtFNm.Size = new System.Drawing.Size(248, 19);
            this.txtFNm.TabIndex = 86;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 115);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 85;
            this.label3.Text = "Father\'s Name";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtSNm
            // 
            this.txtSNm.BackColor = System.Drawing.Color.Snow;
            this.txtSNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSNm.Location = new System.Drawing.Point(126, 89);
            this.txtSNm.Margin = new System.Windows.Forms.Padding(2);
            this.txtSNm.Name = "txtSNm";
            this.txtSNm.Size = new System.Drawing.Size(248, 19);
            this.txtSNm.TabIndex = 84;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 83;
            this.label2.Text = "Full Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(285, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 29);
            this.label1.TabIndex = 82;
            this.label1.Text = "Staff Details";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtContact);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtGardianAdd);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtGardian);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(397, 231);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(181, 166);
            this.groupBox1.TabIndex = 120;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Reference By";
            // 
            // NewStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(605, 486);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.DOF);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtAdhar);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtFormNo);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.comboClass);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtPlaceOfB);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtFoccupation);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtCast);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtReligion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAdd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtMNm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtFNm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSNm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "NewStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NewStaff";
            this.Load += new System.EventHandler(this.NewStaff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker DOF;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtAdhar;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFormNo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboClass;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtPlaceOfB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtFoccupation;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtGardianAdd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.TextBox txtGardian;
        private System.Windows.Forms.TextBox txtCast;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtReligion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMNm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFNm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSNm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}