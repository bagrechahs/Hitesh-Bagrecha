﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique
{
    public partial class Quantity : Form
    {
        public Quantity()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into quantity values('"+textBox1.Text+"','"+textBox2.Text+"')", cn);
            int i = cmd.ExecuteNonQuery();
            MessageBox.Show("Saved");

            textBox1.Clear();
            textBox2.Clear();
            textBox1.Focus();
        }
    }
}
