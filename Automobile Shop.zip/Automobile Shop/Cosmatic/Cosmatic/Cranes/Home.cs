﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bootique
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void newStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewStaff ob = new NewStaff();
            ob.MdiParent = this;
            ob.Show();
        }

        private void searchStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchStaff ob = new SearchStaff();
            ob.MdiParent = this;
            ob.Show();
        }

        private void newCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewCustomer ob = new NewCustomer();
            ob.MdiParent = this;
            ob.Show();
        }

        private void searchCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchCustomer ob = new SearchCustomer();
            ob.MdiParent = this;
            ob.Show();
        }

        private void newPatternToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Product ob = new Product();
            ob.MdiParent = this;
            ob.Show();
        }

        private void newSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quantity ob = new Quantity();
            ob.MdiParent = this;
            ob.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
