﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique
{
    public partial class NewStaff : Form
    {
        public NewStaff()
        {
            InitializeComponent();
        }
        string path = "";
        int tot = 0;
        private void NewStaff_Load(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");

            SqlDataAdapter sda = new SqlDataAdapter("select * from reg1", cn);

            DataSet ds = new DataSet();

            sda.Fill(ds);

            tot = ds.Tables[0].Rows.Count + 1;

            txtFormNo.Text = tot.ToString();

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();

            path = openFileDialog1.FileName;

            pictureBox1.ImageLocation = path;

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = null;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();


            string q = "insert into reg1 values("
                                                    + txtFormNo.Text +
                                                    ",'" + txtSNm.Text +
                                                    "','" + txtFNm.Text +
                                                    "','" + txtMNm.Text +
                                                    "','" + txtAdd.Text +
                                                    "','" + txtReligion.Text +
                                                    "','" + txtCast.Text +
                                                    "','" + txtFoccupation.Text +
                                                    "','" + DOB.Text +
                                                    "','" + txtPlaceOfB.Text +
                                                    "','" + txtAdhar.Text +

                                                    "','" + DOF.Text +
                                                    "','" + comboClass.Text +

                                                    "','" + path +
                                                    "','" + txtGardian.Text +
                                                    "','" + txtGardianAdd.Text +
                                                    "','" + txtContact.Text +
                                                    "')";

            SqlCommand cmd = new SqlCommand(q, cn);

            int i = cmd.ExecuteNonQuery();
            MessageBox.Show(i + " row inserted !","New Staff",MessageBoxButtons.OK,MessageBoxIcon.Information);

            cn.Close();

            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
