﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique
{
    public partial class SearchCustomer : Form
    {
        public SearchCustomer()
        {
            InitializeComponent();
        }

        private void SearchCustomer_Load(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            SqlDataAdapter sda = new SqlDataAdapter("select * from product", cn);
            DataSet ds3 = new DataSet();
            sda.Fill(ds3);

            comboBox1.DataSource = ds3.Tables[0];
            comboBox1.DisplayMember = "ptype";

            
            SqlDataAdapter sda2 = new SqlDataAdapter("select * from quantity", cn);
            DataSet ds2 = new DataSet();
            sda2.Fill(ds2, "quantity");
            comboBox3.DataSource = ds2.Tables[0];
            comboBox3.DisplayMember = "sys";




            label6.Visible = false;
            txtSearch.Visible = false;

            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    TextBox t = (TextBox)c;
                    t.Clear();
                    if (t.Name != "txtSearch")
                    {
                        t.Enabled = false;
                    }
                }
                if (c is DateTimePicker)
                {
                    DateTimePicker d = (DateTimePicker)c;
                    d.Enabled = false;
                }
                if (c is ComboBox)
                {
                    ComboBox cb = (ComboBox)c;
                    cb.Enabled = false;
                }
                if (c is Button)
                {
                    Button b = (Button)c;

                    if (b.Name != "btnSearch")
                    {
                        b.Visible = false;
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            SqlDataAdapter sda = new SqlDataAdapter("select * from product where ptype = '" + comboBox1.Text + "'", cn);
            DataSet ds1 = new DataSet();
            sda.Fill(ds1, "product");
            comboBox2.DataSource = ds1.Tables[0];
            comboBox2.DisplayMember = "pname";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label6.Visible = true; ;
            txtSearch.Visible = true;
            txtSearch.Focus();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label6.Visible = true; ;
            txtSearch.Visible = true;
            txtSearch.Focus();
        }
        SqlDataAdapter sd;
        DataSet ds = new DataSet();
        private void btnSearch_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            if (radioButton1.Checked == true)
            {
                sd = new SqlDataAdapter("select * from customers where id=" + txtSearch.Text, cn);
            }
            if (radioButton2.Checked == true)
                sd = new SqlDataAdapter("select * from customers where adhar='" + txtSearch.Text + "'", cn);
            
            sd.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                txtFormNo.Text = ds.Tables[0].Rows[0][0].ToString();
                txtfn.Text = ds.Tables[0].Rows[0][1].ToString();
                txtAdd.Text = ds.Tables[0].Rows[0][2].ToString();
                txtAdhar.Text = ds.Tables[0].Rows[0][3].ToString();
                txtContact.Text = ds.Tables[0].Rows[0][4].ToString();
                comboBox1.Text = ds.Tables[0].Rows[0][5].ToString();
                comboBox2.Text = ds.Tables[0].Rows[0][6].ToString();
                comboBox3.Text = ds.Tables[0].Rows[0][7].ToString();
                txtCharge.Text = ds.Tables[0].Rows[0][8].ToString();
                DOR.Text = ds.Tables[0].Rows[0][9].ToString();
                txtPaid.Text = ds.Tables[0].Rows[0][10].ToString();
                txtRemaining.Text = ds.Tables[0].Rows[0][11].ToString();

                foreach (Control c in this.Controls)
                {
                    if (c is TextBox)
                    {
                        TextBox t = (TextBox)c;

                        if (t.Name != "txtSearch")
                        {
                            t.Enabled = true;
                        }
                    }
                    if (c is DateTimePicker)
                    {
                        DateTimePicker d = (DateTimePicker)c;
                        d.Enabled = true;
                    }
                    if (c is ComboBox)
                    {
                        ComboBox cb = (ComboBox)c;
                        cb.Enabled = true;
                    }
                    if (c is Button)
                    {
                        if (c.Name != "btnDelete")
                        {
                            Button b = (Button)c;
                            b.Visible = true;
                        }
                    }
                }

                
            }
            else
            {
                MessageBox.Show("Data Not Found");
                txtSearch.Clear();
                txtSearch.Focus();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();
            string q = "";
            if (radioButton1.Checked == true)
                q = "update customers set name = '" + txtfn.Text + "', address = '" + txtAdd.Text + "', adhar = '" + txtAdhar.Text + "', contact = '" + txtContact.Text + "', ptype = '" + comboBox1.Text + "', pname = '" + comboBox2.Text + "', quantity = '" + comboBox3.Text + "', charges = '" + txtCharge.Text + "', dor = '" + DOR.Text + "', paid = '" + txtPaid.Text + "', remaining = '" + txtRemaining.Text + "' where id = " + txtSearch.Text;

            if (radioButton2.Checked == true)
                q = "update customers set name = '" + txtfn.Text + "', address = '" + txtAdd.Text + "', adhar = '" + txtAdhar.Text + "', contact = '" + txtContact.Text + "', ptype = '" + comboBox1.Text + "', pname = '" + comboBox2.Text + "', quantity = '" + comboBox3.Text + "', charges = '" + txtCharge.Text + "', dor = '" + DOR.Text + "', paid = '" + txtPaid.Text + "', remaining = '" + txtRemaining.Text + "' where adhar = '" + txtSearch.Text + "'";
            
            SqlCommand cmd = new SqlCommand(q, cn);

            int i = cmd.ExecuteNonQuery();

            MessageBox.Show(i + " row updated");

            cn.Close();

            //this.Hide();
        }

        private void btnDeete_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();
            string q = "";
            if (radioButton1.Checked == true)
                q = "delete from customers where id = " + txtSearch.Text;

            if (radioButton2.Checked == true)
                q = "delete from customers where adhar = '" + txtSearch.Text + "'";

            SqlCommand cmd = new SqlCommand(q, cn);

            int i = cmd.ExecuteNonQuery();

            MessageBox.Show(i + " row deleted");

            cn.Close();

            //this.Hide();
        }

        private void txtRemaining_Click(object sender, EventArgs e)
        {

            int x = int.Parse(txtCharge.Text);
            int y = int.Parse(txtPaid.Text);
            int z = x - y;
            txtRemaining.Text = z.ToString();
        }

        private void txtCharge_Click(object sender, EventArgs e)
        {
           
        }
    }
}
