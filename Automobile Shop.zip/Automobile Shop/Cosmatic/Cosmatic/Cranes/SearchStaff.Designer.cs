﻿namespace Bootique
{
    partial class SearchStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchStaff));
            this.txtAdhar = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnchange = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.comboClass = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.txtFOccu = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtGAdd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtFormNo = new System.Windows.Forms.TextBox();
            this.DOA = new System.Windows.Forms.DateTimePicker();
            this.txtPlaceOfB = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtGNm = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCast = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtReligion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMNm = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFNm = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSNm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAdhar
            // 
            this.txtAdhar.BackColor = System.Drawing.Color.Snow;
            this.txtAdhar.Location = new System.Drawing.Point(126, 396);
            this.txtAdhar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdhar.Name = "txtAdhar";
            this.txtAdhar.Size = new System.Drawing.Size(248, 20);
            this.txtAdhar.TabIndex = 162;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(13, 396);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 13);
            this.label18.TabIndex = 161;
            this.label18.Text = "Adhar No.";
            // 
            // btnSearch
            // 
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.Location = new System.Drawing.Point(126, 11);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(115, 31);
            this.btnSearch.TabIndex = 158;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(522, 379);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(97, 37);
            this.btnDelete.TabIndex = 160;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.Location = new System.Drawing.Point(391, 379);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(125, 37);
            this.btnUpdate.TabIndex = 159;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtContact
            // 
            this.txtContact.BackColor = System.Drawing.Color.Snow;
            this.txtContact.Enabled = false;
            this.txtContact.Location = new System.Drawing.Point(9, 152);
            this.txtContact.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(119, 20);
            this.txtContact.TabIndex = 157;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 134);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 13);
            this.label17.TabIndex = 156;
            this.label17.Text = "Contact No.";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(413, 44);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 13);
            this.label16.TabIndex = 155;
            this.label16.Text = "Staff Image";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Snow;
            this.btnClear.Location = new System.Drawing.Point(471, 155);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(53, 19);
            this.btnClear.TabIndex = 154;
            this.btnClear.Text = "clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Visible = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnchange
            // 
            this.btnchange.BackColor = System.Drawing.Color.Snow;
            this.btnchange.Location = new System.Drawing.Point(391, 155);
            this.btnchange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnchange.Name = "btnchange";
            this.btnchange.Size = new System.Drawing.Size(60, 19);
            this.btnchange.TabIndex = 153;
            this.btnchange.Text = "change";
            this.btnchange.UseVisualStyleBackColor = false;
            this.btnchange.Visible = false;
            this.btnchange.Click += new System.EventHandler(this.btnchange_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox1.Location = new System.Drawing.Point(391, 64);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 79);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 152;
            this.pictureBox1.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(11, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 13);
            this.label15.TabIndex = 150;
            this.label15.Text = "Enter Form No.";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(10, 364);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 13);
            this.label14.TabIndex = 148;
            this.label14.Text = "Date Of Joining";
            // 
            // comboClass
            // 
            this.comboClass.BackColor = System.Drawing.Color.Snow;
            this.comboClass.Enabled = false;
            this.comboClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboClass.FormattingEnabled = true;
            this.comboClass.Location = new System.Drawing.Point(126, 317);
            this.comboClass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboClass.Name = "comboClass";
            this.comboClass.Size = new System.Drawing.Size(176, 21);
            this.comboClass.TabIndex = 147;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(11, 320);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 13);
            this.label13.TabIndex = 146;
            this.label13.Text = "Post";
            // 
            // DOB
            // 
            this.DOB.Enabled = false;
            this.DOB.Location = new System.Drawing.Point(126, 253);
            this.DOB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(176, 20);
            this.DOB.TabIndex = 143;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(11, 257);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 13);
            this.label11.TabIndex = 142;
            this.label11.Text = "Date Of Birth";
            // 
            // txtFOccu
            // 
            this.txtFOccu.BackColor = System.Drawing.Color.Snow;
            this.txtFOccu.Enabled = false;
            this.txtFOccu.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFOccu.Location = new System.Drawing.Point(126, 220);
            this.txtFOccu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFOccu.Name = "txtFOccu";
            this.txtFOccu.Size = new System.Drawing.Size(248, 19);
            this.txtFOccu.TabIndex = 141;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 220);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 13);
            this.label10.TabIndex = 140;
            this.label10.Text = "Father\'s occupation";
            // 
            // txtGAdd
            // 
            this.txtGAdd.BackColor = System.Drawing.Color.Snow;
            this.txtGAdd.Enabled = false;
            this.txtGAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGAdd.Location = new System.Drawing.Point(9, 88);
            this.txtGAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGAdd.Multiline = true;
            this.txtGAdd.Name = "txtGAdd";
            this.txtGAdd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtGAdd.Size = new System.Drawing.Size(215, 33);
            this.txtGAdd.TabIndex = 139;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 13);
            this.label9.TabIndex = 138;
            this.label9.Text = "Refference Address";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txtFormNo
            // 
            this.txtFormNo.Location = new System.Drawing.Point(15, 25);
            this.txtFormNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFormNo.Name = "txtFormNo";
            this.txtFormNo.Size = new System.Drawing.Size(88, 20);
            this.txtFormNo.TabIndex = 151;
            // 
            // DOA
            // 
            this.DOA.Enabled = false;
            this.DOA.Location = new System.Drawing.Point(126, 364);
            this.DOA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DOA.Name = "DOA";
            this.DOA.Size = new System.Drawing.Size(176, 20);
            this.DOA.TabIndex = 149;
            // 
            // txtPlaceOfB
            // 
            this.txtPlaceOfB.BackColor = System.Drawing.Color.Snow;
            this.txtPlaceOfB.Enabled = false;
            this.txtPlaceOfB.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlaceOfB.Location = new System.Drawing.Point(126, 287);
            this.txtPlaceOfB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPlaceOfB.Name = "txtPlaceOfB";
            this.txtPlaceOfB.Size = new System.Drawing.Size(248, 19);
            this.txtPlaceOfB.TabIndex = 145;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(11, 287);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 144;
            this.label12.Text = "Place of Birth";
            // 
            // txtGNm
            // 
            this.txtGNm.BackColor = System.Drawing.Color.Snow;
            this.txtGNm.Enabled = false;
            this.txtGNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGNm.Location = new System.Drawing.Point(9, 39);
            this.txtGNm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGNm.Name = "txtGNm";
            this.txtGNm.Size = new System.Drawing.Size(215, 19);
            this.txtGNm.TabIndex = 137;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 136;
            this.label8.Text = "Refference Name";
            // 
            // txtCast
            // 
            this.txtCast.BackColor = System.Drawing.Color.Snow;
            this.txtCast.Enabled = false;
            this.txtCast.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCast.Location = new System.Drawing.Point(286, 187);
            this.txtCast.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCast.Name = "txtCast";
            this.txtCast.Size = new System.Drawing.Size(88, 19);
            this.txtCast.TabIndex = 135;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(237, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 134;
            this.label7.Text = "Cast";
            // 
            // txtReligion
            // 
            this.txtReligion.BackColor = System.Drawing.Color.Snow;
            this.txtReligion.Enabled = false;
            this.txtReligion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReligion.Location = new System.Drawing.Point(126, 187);
            this.txtReligion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtReligion.Name = "txtReligion";
            this.txtReligion.Size = new System.Drawing.Size(88, 19);
            this.txtReligion.TabIndex = 133;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 132;
            this.label6.Text = "Religion";
            // 
            // txtAdd
            // 
            this.txtAdd.BackColor = System.Drawing.Color.Snow;
            this.txtAdd.Enabled = false;
            this.txtAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdd.Location = new System.Drawing.Point(126, 141);
            this.txtAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdd.Multiline = true;
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAdd.Size = new System.Drawing.Size(248, 33);
            this.txtAdd.TabIndex = 131;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 130;
            this.label5.Text = "Address";
            // 
            // txtMNm
            // 
            this.txtMNm.BackColor = System.Drawing.Color.Snow;
            this.txtMNm.Enabled = false;
            this.txtMNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMNm.Location = new System.Drawing.Point(126, 109);
            this.txtMNm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMNm.Name = "txtMNm";
            this.txtMNm.Size = new System.Drawing.Size(248, 19);
            this.txtMNm.TabIndex = 129;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 128;
            this.label4.Text = "Mother\'s Name";
            // 
            // txtFNm
            // 
            this.txtFNm.BackColor = System.Drawing.Color.Snow;
            this.txtFNm.Enabled = false;
            this.txtFNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFNm.Location = new System.Drawing.Point(126, 79);
            this.txtFNm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFNm.Name = "txtFNm";
            this.txtFNm.Size = new System.Drawing.Size(248, 19);
            this.txtFNm.TabIndex = 127;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 126;
            this.label3.Text = "Father\'s Name";
            // 
            // txtSNm
            // 
            this.txtSNm.BackColor = System.Drawing.Color.Snow;
            this.txtSNm.Enabled = false;
            this.txtSNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSNm.Location = new System.Drawing.Point(126, 53);
            this.txtSNm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSNm.Name = "txtSNm";
            this.txtSNm.Size = new System.Drawing.Size(248, 19);
            this.txtSNm.TabIndex = 125;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 124;
            this.label2.Text = "Staff Full Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(302, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 24);
            this.label1.TabIndex = 123;
            this.label1.Text = "Staff Searching Form";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtContact);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtGAdd);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtGNm);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(382, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(236, 186);
            this.groupBox1.TabIndex = 163;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Reference by";
            // 
            // SearchStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(631, 442);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtAdhar);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnchange);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.comboClass);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtFOccu);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtFormNo);
            this.Controls.Add(this.DOA);
            this.Controls.Add(this.txtPlaceOfB);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtCast);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtReligion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAdd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtMNm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtFNm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSNm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "SearchStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchStaff";
            this.Load += new System.EventHandler(this.SearchStaff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAdhar;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnchange;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboClass;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtFOccu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtGAdd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtFormNo;
        private System.Windows.Forms.DateTimePicker DOA;
        private System.Windows.Forms.TextBox txtPlaceOfB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtGNm;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCast;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtReligion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMNm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFNm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSNm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}