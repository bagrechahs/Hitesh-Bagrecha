﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            
            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();

            string q = "select * from login where un = '" + txtUN.Text + "' AND pw = '" + txtPW.Text + "'";
            SqlCommand cmd = new SqlCommand(q, cn);

            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                MessageBox.Show("Login Successfull !");
                this.Hide();
                Splash s = new Splash();
                s.Show();
            }
            else
            {
                MessageBox.Show("Login Fail !");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToLongTimeString();
            label4.Text = DateTime.Now.ToShortDateString();

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
