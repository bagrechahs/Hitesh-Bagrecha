﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into product values('" + comboBox1.Text + "','" + textBox1.Text + "')", cn);
            int i = cmd.ExecuteNonQuery();
            MessageBox.Show("Saved", "Product",MessageBoxButtons.OK,MessageBoxIcon.Information);

            textBox1.Clear();
            comboBox1.Text = "select Type";
            details();
        }

        private void Dress_Load(object sender, EventArgs e)
        {
            details();
        }
        public void details()
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            SqlDataAdapter sda = new SqlDataAdapter("select * from product", cn);
            DataSet ds = new DataSet();
            sda.Fill(ds, "p");
            dataGridView1.DataSource = ds.Tables[0];
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.DisplayMember = "ptype";
        }
    }
}
