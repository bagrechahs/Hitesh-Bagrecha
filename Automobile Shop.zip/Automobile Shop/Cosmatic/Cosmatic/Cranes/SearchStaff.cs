﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique
{
    public partial class SearchStaff : Form
    {
        public SearchStaff()
        {
            InitializeComponent();
        }
        string p;
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataAdapter sda;
        DataSet ds = new DataSet();
        private void SearchStaff_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    TextBox t = (TextBox)c;
                    t.Clear();
                    if (t.Name != "txtFormNo")
                    {
                        t.Enabled = false;
                    }
                }
                if (c is DateTimePicker)
                {
                    DateTimePicker d = (DateTimePicker)c;
                    d.Enabled = false;
                }
                if (c is ComboBox)
                {
                    ComboBox cb = (ComboBox)c;
                    cb.Enabled = false;
                }
                if (c is Button)
                {
                    Button b = (Button)c;

                    if (b.Name != "btnSearch")
                    {
                        b.Visible = false;
                    }
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");

            sda = new SqlDataAdapter("select * from reg1 where formno=" + txtFormNo.Text, cn);

            sda.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                txtSNm.Text = ds.Tables[0].Rows[0][1].ToString();
                txtFNm.Text = ds.Tables[0].Rows[0][2].ToString();
                txtMNm.Text = ds.Tables[0].Rows[0][3].ToString();
                txtAdd.Text = ds.Tables[0].Rows[0][4].ToString();
                txtReligion.Text = ds.Tables[0].Rows[0][5].ToString();
                txtCast.Text = ds.Tables[0].Rows[0][6].ToString();
                txtFOccu.Text = ds.Tables[0].Rows[0][7].ToString();
                DOB.Text = ds.Tables[0].Rows[0][8].ToString();
                txtPlaceOfB.Text = ds.Tables[0].Rows[0][9].ToString();
                txtAdhar.Text = ds.Tables[0].Rows[0][10].ToString();
                //txtPreSchool.Text = ds.Tables[0].Rows[0][11].ToString();
                //DOF.Text = ds.Tables[0].Rows[0][12].ToString();
                comboClass.Text = ds.Tables[0].Rows[0][12].ToString();
                DOA.Text = ds.Tables[0].Rows[0][11].ToString();

                p = ds.Tables[0].Rows[0][13].ToString();
                pictureBox1.ImageLocation = p;

                txtGNm.Text = ds.Tables[0].Rows[0][14].ToString();
                txtGAdd.Text = ds.Tables[0].Rows[0][15].ToString();
                txtContact.Text = ds.Tables[0].Rows[0][16].ToString();




                foreach (Control c in this.Controls)
                {
                    if (c is TextBox)
                    {
                        TextBox t = (TextBox)c;

                        if (t.Name != "txtFormNo")
                        {
                            t.Enabled = true;
                        }
                    }
                    if (c is DateTimePicker)
                    {
                        DateTimePicker d = (DateTimePicker)c;
                        d.Enabled = true;
                    }
                    if (c is ComboBox)
                    {
                        ComboBox cb = (ComboBox)c;
                        cb.Enabled = true;
                    }
                    if (c is Button)
                    {
                        if (c.Name != "btnDelete")
                        {
                            Button b = (Button)c;
                            b.Visible = true;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Data Not Found");
                txtFormNo.Clear();
                txtFormNo.Focus();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();


            string q = "update reg1 set sname = '" + txtSNm.Text + "', fname = '" + txtFNm.Text + "', mname = '" + txtMNm.Text + "', address = '" + txtAdd.Text + "', religion = '" + txtReligion.Text + "', cast = '" + txtCast.Text + "', occupation = '" + txtFOccu.Text + "', dob = '" + DOB.Text + "', place = '" + txtPlaceOfB.Text + "', adhar = '" + txtAdhar.Text + "', dof = '" + DOA.Text + "', class = '" + comboClass.Text + "', photo = '" + p + "', gname = '" + txtGNm.Text + "', gaddress = '" + txtGAdd.Text + "', contact = '" + txtContact.Text + "' where formno = " + txtFormNo.Text;
                                          
            SqlCommand cmd = new SqlCommand(q, cn);

            int i = cmd.ExecuteNonQuery();

            MessageBox.Show(i + " row updated");

            cn.Close();

            this.Hide();
        }

        private void btnchange_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            p = openFileDialog1.FileName;
            pictureBox1.ImageLocation = p;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            p = null;
            pictureBox1.ImageLocation = null;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();

            SqlCommand cmd = new SqlCommand("delete from reg1 where formno = " + txtFormNo.Text, cn);

            int i = cmd.ExecuteNonQuery();


            pictureBox1.ImageLocation = null;

            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    TextBox t = (TextBox)c;
                    t.Clear();

                }
                if (c is DateTimePicker)
                {
                    DateTimePicker d = (DateTimePicker)c;
                    d.Text = "";
                }
                if (c is ComboBox)
                {

                    ComboBox cb = (ComboBox)c;
                    cb.Text = "";
                }
                if (c is Button)
                {
                    Button b = (Button)c;

                    if (b.Name != "btnSearch")
                    {
                        b.Visible = false;
                    }
                }
            }


            MessageBox.Show(i + " row deleted");

            this.Hide();
        }
    }
}
