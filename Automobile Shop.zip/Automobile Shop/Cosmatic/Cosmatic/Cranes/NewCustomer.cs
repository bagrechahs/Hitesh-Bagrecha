﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bootique
{
    public partial class NewCustomer : Form
    {
        public NewCustomer()
        {
            InitializeComponent();
        }
        string str = "";
        int tot = 0;
        private void NewCustomer_Load(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            SqlDataAdapter sda = new SqlDataAdapter("select * from product", cn);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            comboBox1.DataSource = ds.Tables[0];
            comboBox1.DisplayMember = "ptype";




            SqlConnection con = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");

            SqlDataAdapter sda1 = new SqlDataAdapter("select * from customers", con);

            DataSet ds1 = new DataSet();

            sda1.Fill(ds1);

            tot = ds1.Tables[0].Rows.Count + 1;

            txtFormNo.Text = tot.ToString();

            SqlDataAdapter sda2 = new SqlDataAdapter("select * from quantity", con);
            DataSet ds2 = new DataSet();
            sda2.Fill(ds2, "quantity");
            comboBox3.DataSource = ds2.Tables[0];
            comboBox3.DisplayMember = "sym";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            SqlDataAdapter sda = new SqlDataAdapter("select * from product where ptype = '" + comboBox1.Text + "'", cn);
            DataSet ds = new DataSet();
            sda.Fill(ds, "product");
            comboBox2.DataSource = ds.Tables[0];
            comboBox2.DisplayMember = "pname";
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"uid=sa;password=123;server=user-pc;database=automobile");
            cn.Open();

            string q = "insert into customers values("
                                                    + txtFormNo.Text +
                                                    ",'" + txtfn.Text +
                                                    "','" + txtAdd.Text +
                                                    "','" + txtAdhar.Text +
                                                    "','" + txtContact.Text +
                                                    "','" + comboBox1.Text +
                                                    "','" + comboBox2.Text +
                                                    "','" + comboBox3.Text +
                                                    "','" + txtCharge.Text +
                                                    "','" + DOR.Text +
                                                    "','" + txtPaid.Text +
                                                    "','" + txtRemaining.Text +
                                                    "')";

            SqlCommand cmd = new SqlCommand(q, cn);

            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                MessageBox.Show(i + " row inserted !");
            }
            else {
                MessageBox.Show(i + " row inserted !");
            }
            cn.Close();


            //this.Hide();


        }

        private void txtRemaining_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRemaining_Click(object sender, EventArgs e)
        {
            int x = int.Parse(txtCharge.Text);
            int y = int.Parse(txtPaid.Text);
            int z = x - y;
            txtRemaining.Text = z.ToString();
        }

        private void btnBill_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawRectangle(new Pen(Brushes.Black), new Rectangle(150, 200, 600, 550));
            e.Graphics.DrawString("ID No.                  : " + txtFormNo.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200,250 ));
            e.Graphics.DrawString("Name                   : " + txtfn.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 290));
            e.Graphics.DrawString("Product Type     : " + comboBox1.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 330));
            e.Graphics.DrawString("Product Name     : " + comboBox2.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 370));
            e.Graphics.DrawString("Quantity               : " + comboBox3.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 410));

            e.Graphics.DrawString("Toatal Charges  :" + txtCharge.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 450));

            
            e.Graphics.DrawString("Paid                       : " + txtPaid.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 490));
            e.Graphics.DrawString("Remaining            : " + txtRemaining.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 530));
            e.Graphics.DrawString("DOP                       : " + DOR.Text, new Font("Arial", 16, FontStyle.Bold), Brushes.Black, new Point(200, 570));

            e.Graphics.DrawString("Jain Spare Parts Automobiles", new Font("Comic Sans MS", 24, FontStyle.Bold), Brushes.BlueViolet, new Point(200, 650));
        }

        private void txtAdd_TextChanged(object sender, EventArgs e)
        {

        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void txtCharge_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DOR_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
