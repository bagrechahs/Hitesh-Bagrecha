create database automobile

use automobile

create table login(un varchar(30),pw int)

insert into login values('admin',12345)

create table quantity(qname varchar(30),sym varchar(30))

create table product(ptype varchar(30),pname varchar(30))


create table reg1(formno int primary key, sname varchar(30), fname varchar(30), mname varchar(30), address varchar(30), religion varchar(30), cast varchar(30), occupation varchar(30), dob varchar(30), place varchar(30),adhar varchar(30), dof varchar(30), class varchar(30),  photo varchar(300), gname varchar(30), gaddress varchar(30), contact varchar(30))
select * from reg1

create table customers(id int primary key,name varchar(30),address varchar(30),adhar varchar(30),contact varchar(30),ptype varchar(30),pname varchar(30),quantity varchar(30),charges varchar(30),dor varchar(30),paid varchar(30),remaining varchar(30))

select * from customers

delete from product